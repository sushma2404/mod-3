package com.capgemini;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class TestApp {
	public static void main(String args[])
	{
		XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("application.xml"));
		ApplicationContext context=new FileSystemXmlApplicationContext("C:\\Users\\dchundru\\SpringwelcomeApp\\src\\application.xml");
	 Employee emp=context.getBean("emp",Employee.class);
        Employee emp2=context.getBean("emp",Employee.class);
        System.out.println(emp);
       System.out.println(emp2);
		//Employee emp=factory.getBean("emp",Employee.class);
		/*
		 * Address add=factory.getBean("addr",Address.class); System.out.println(emp);
		 */
		//System.out.println(emp.getAddress().getCity());
		//System.out.println(add.getCity());
		/*
		 * System.out.println(emp.getSkills()); System.out.println(emp.getProjects());
		 * System.out.println(emp.getTeamMates()); System.out.println(emp.getAddress());
		 */
		
	}

}
