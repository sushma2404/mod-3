package com.capg.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.capg.beans.ErrorInfo;
@ControllerAdvice
public class GlobalException extends Exception{
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason="Employee doesnot exist")
	@ExceptionHandler({GlobalException.class})
	public  ErrorInfo handleConflict(GlobalException ex, HttpServletRequest req)
	{
		String bodyOfResponse=ex.getMessage();
		String uri=req.getRequestURL().toString();
		return new ErrorInfo(uri,bodyOfResponse);
		
	}
	
}
