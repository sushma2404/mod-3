insert into employee values(1,'sushma',2000);
insert into employee values(2,'pari',2000);