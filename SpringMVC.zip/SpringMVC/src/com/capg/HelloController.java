package com.capg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class HelloController {
	
	@RequestMapping("/")
	public String sayHello(Model model)
	{
		//System.out.println("hie");
		//Employee emp =new Employee();
	//	emp.setEid(1);
	//	emp.setEname("sushma");
	//	emp.setSalary(20000);
		//ModelAndView mv=new ModelAndView("index","emp",emp);
		//ModelAndView mv=new ModelAndView();
	//	mv.addObject("emp", emp);
	//	mv.setViewName("index");
	//	model.addAttribute("emp",emp);
		
		
		
	return "index";
	}

}
