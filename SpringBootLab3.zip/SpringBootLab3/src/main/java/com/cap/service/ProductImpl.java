package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.beans.Product;
import com.capg.dao.ProductDao;


@Service
public class ProductImpl implements IProduct{

	@Autowired
	ProductDao dao;
	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Product addProduct(Product p) {
		// TODO Auto-generated method stub
		return dao.save(p);
	}
	

}
