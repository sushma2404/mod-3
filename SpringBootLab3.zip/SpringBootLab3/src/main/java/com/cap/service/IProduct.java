package com.cap.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capg.beans.Product;

public interface IProduct {
	
	public List<Product> getAllProducts();
	
	public Product addProduct(Product p);


}
