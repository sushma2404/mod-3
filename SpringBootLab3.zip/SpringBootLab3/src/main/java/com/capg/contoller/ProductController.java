package com.capg.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.service.IProduct;
import com.cap.service.ProductImpl;
import com.capg.beans.Product;

@RestController
public class ProductController {
	
	
	@Autowired
	IProduct service;
	@GetMapping(path="/employees",produces= "application/xml")
	public List<Product> getAllProducts()
	{
	 return  service.getAllProducts();
		
	}
	

}
