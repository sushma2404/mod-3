package com.capg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {
	
	@RequestMapping(value="/display",method=RequestMethod.GET)
	public String display(@RequestParam("uname") String uname, @RequestParam("pwd") String pwd, Model m)
	{
		
		User user=new User();
		user.setUname(uname);
		user.setPwd(pwd);
	    m.addAttribute("user",user);	
	
		return "success";
	}

}
