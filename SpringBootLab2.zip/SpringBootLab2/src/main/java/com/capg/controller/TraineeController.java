package com.capg.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cap.service.TraineeServiceImpl;


@Controller
public class TraineeController {
	
	@Autowired
	TraineeServiceImpl service;
	@RequestMapping("/")
	public String login() {
		return "login";
	}
	@RequestMapping(value="/submitForm",method=RequestMethod.GET)
	public String submitForm()
	{
		return "operation";
	}
	@RequestMapping(value="/add",method=RequestMethod.GET)
	public String AddForm()
	{
		return "addform";
	}
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteForm()
	{
		return "deleteform";
	}
	@RequestMapping(value="/modify",method=RequestMethod.GET)
	public String modifyForm()
	{
		return "modifyform";
	}
	@RequestMapping(value="/retrive",method=RequestMethod.GET)
	public String retriveForm()
	{
		return "retriveform";
	}
	@RequestMapping(value="/retriveall",method=RequestMethod.GET)
	public String retriveAllForm()
	{
		return "retriveallform";
	}
	@RequestMapping(value="/addform",method=RequestMethod.GET)
	public String AddTrainee()
	{
		return "data added";
	}
	
	
}
