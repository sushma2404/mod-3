package com.cap.service;

import java.util.List;



import com.capg.bean.Trainee;


public interface TraineeService {
	
	public Trainee addTraniee(Trainee t);
	public void deleteTraniee(int traineeId);
	public Trainee updateEmployee(Trainee t);
	public List<Trainee> getAllTrainee();
	public Trainee getTraineeById(int traineeId);
}
