package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Trainee;
import com.capg.dao.TraineeDao;

@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao dao;
	@Override
	public Trainee addTraniee(Trainee t) {
		// TODO Auto-generated method stub
		return dao.save(t);
	}
	@Override
	public void deleteTraniee(int traineeId) {
		// TODO Auto-generated method stub
		 dao.deleteById(traineeId);
	}
	@Override
	public List<Trainee> getAllTrainee() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}
	@Override
	public Trainee getTraineeById(int traineeId) {
		// TODO Auto-generated method stub
		return dao.findById(traineeId).orElse(new Trainee());
	}
	@Override
	public Trainee updateEmployee(Trainee t) {
		// TODO Auto-generated method stub
		return  dao.save(t);
	}

}
