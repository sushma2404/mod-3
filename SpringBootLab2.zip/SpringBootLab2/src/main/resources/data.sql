insert into trainee values(1,'sushma','jee','chennai');
insert into trainee  values(2,'pari','.net','mumbai');
