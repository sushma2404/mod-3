package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cap.exception.GlobalException;
import com.capg.bean.Product;
import com.capg.service.IProductService;

@RestController
public class ProductController {
	@Autowired
	IProductService service;
   @PostMapping(path="/product",consumes="application/json")
	
	public Product addProduct(@RequestBody Product pro)
	{
	   return service.add(pro);
		
	}
   @GetMapping(path="/products")
	public List<Product> getAllProducts()
	{
	 return  service.display();
		
	}

	@DeleteMapping(path="/product/{pid}")
	public void deleteProductById(@PathVariable int pid) //throws GlobalException
	{
		//if(pid==0)
		//	throw new GlobalException();	
	    service.delete(pid);
	
    }
	@PutMapping(path="/product",consumes="application/json")
	public Product UpdateProduct(@RequestBody Product pro)
	{
	   return service.update(pro);
		
	}
}
