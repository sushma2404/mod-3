package com.capg.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Product {
	
	@Id
	@NotNull(message = "Id is manditory")
	private int pid;
	@NotNull(message = "Name is manditory")
	@Size(min=3,max=20)
	private String pname;
	@Max(value=90000,message="must be equal or less than 90000")
	private double price;
	@Size(min=10,max=10,message="Mobile number must be 10 digits")
	private long mno;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public long getMno() {
		return mno;
	}
	public void setMno(long mno) {
		this.mno = mno;
	}
	@Override
	public String toString() {
		return "Product [pid=" + pid + ", pname=" + pname + ", price=" + price + ", mno=" + mno + "]";
	}
}
