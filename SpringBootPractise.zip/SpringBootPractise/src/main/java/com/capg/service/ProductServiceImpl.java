package com.capg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Product;
import com.capg.dao.ProductDao;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	ProductDao repo;
	@Override
	public Product add(Product pro) {
		// TODO Auto-generated method stub
		return repo.save(pro);
	}

	@Override
	public Product fetch(int pid) {
		// TODO Auto-generated method stub
		return repo.findById(pid).orElse(new Product());
	}

	@Override
	public List<Product> display() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public void delete(int pid) {
		// TODO Auto-generated method stub
		repo.deleteById(pid);
	}

	@Override
	public Product update(Product pro) {
		// TODO Auto-generated method stub
		return repo.save(pro);
		
	}

}
