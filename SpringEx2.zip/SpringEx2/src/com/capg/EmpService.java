package com.capg;

import org.springframework.stereotype.Service;

@Service
public class EmpService {
	

}
