package com.capg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
@Configuration
public class Client {
	@Autowired
    static EmpService service;
	

	public static void main(String args[]) {
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		//System.out.println("empservice :"+service);
		context.scan("com.capg");
		context.refresh();
		Employee emp=context.getBean("emp",Employee.class);
		/*
		 * Employee emp1=context.getBean("emp",Employee.class); emp.setEname("sushma");
		 * System.out.println(emp.getAddress()); System.out.println(emp1);
		 */
		//EmpService emp2=context.getBean("s1", Empservice.class);
		System.out.println(emp.getAddress());
		
		
		
		
	}
	/*
	 * @Bean(name = "e1")
	 * 
	 * @Scope("singleton") public Employee getEmpObj() { return new Employee(); }
	 */
}
